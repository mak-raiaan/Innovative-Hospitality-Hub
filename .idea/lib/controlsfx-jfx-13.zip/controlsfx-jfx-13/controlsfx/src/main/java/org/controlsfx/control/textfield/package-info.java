/**
 * A package containing a number of useful classes related to text input.
 */
package org.controlsfx.control.textfield;